package starter.reqres;

import org.hamcrest.Matcher;

public class ReqresResponses {

    public static final String PAGE ="page";
    public static final String NAME ="name";
    public static final String JOB =" job";
    public static final String PASSWORD = "password";
    public static final String TOKEN = "token";
    public static final String ID = "id";
    public static final String ERROR = "error";
    public static final String DELAY = "delay";
}