package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;

import java.io.File;

import static org.hamcrest.core.IsEqual.equalTo;

public class PostCreateUSerStepDef {
    @Steps
    ReqresAPI reqresAPI;

    @Given("Create post user with invalid json")
    public void postCreateUserWithInalidJson() {
        File json= new File (ReqresAPI.JSON_REQUEST+"/PostCreateUserInvalid.json");
        reqresAPI.postCreateUserInvalid(json);
    }
    @When("Send Request post create user invalid")
    public void sendRequestPostCreateUserInvalid(){
        SerenityRest.when().post(ReqresAPI.POST_CREATE_USER);
    }
//    @Then("Should return status code {int}")
//    public void statusCodeShouldBe(int code) {
//        SerenityRest.then().statusCode(code);}
}
