package starter.reqres.StepDef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;

public class SingleUserStepDef {

    @Steps
    ReqresAPI reqresAPI;

    @Given("Get single user with parameter invalid id {string}")
    public void getSingleUserWithParameterInvalidID(String id){ reqresAPI.getSingleUsers(id);}



    @When("Send get single user request")
    public void sendGetSingleUserRequest() {
        SerenityRest.when().get(ReqresAPI.GET_SINGLE_USER); }





}
