package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.module.jsv.JsonSchemaValidator;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;

import java.io.File;

public class DelayedResponseStepDef {
    @Steps
    ReqresAPI reqresAPI;

    @Given("Get delayed with valid parameter page {int}")
    public void getDelayedResponse(int delay){
        reqresAPI.getDelayedResponse(delay);
    }

    @Given("Get delayed with invalid parameter page {int}")
    public void getDelayedResponseInvalid(int delay){
    }

    @When("Send request get delayed response")
    public void sendRequestGetDelayedResponse(){
        SerenityRest.when().get(ReqresAPI.GET_DELAYED_RESPONSE); }

    @And("Validate json schema get delayed response")
    public void validateJsonSchemaGetDelayedResponse() {
        File json = new File(ReqresAPI.JSON_SCHEMA +"/DelayedResponseSchema.json");
        SerenityRest.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(json));}










}

