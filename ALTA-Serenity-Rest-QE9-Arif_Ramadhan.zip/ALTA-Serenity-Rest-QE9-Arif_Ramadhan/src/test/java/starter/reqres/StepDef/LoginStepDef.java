package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;
import starter.reqres.ReqresResponses;

import java.io.File;

import static org.hamcrest.Matchers.equalTo;

public class LoginStepDef {

    @Steps
    ReqresAPI reqresAPI;

    //login Successful
    @Given("Post login user with valid json")
    public void postLoginSuccessfulWithValidJson() {
        File json= new File (ReqresAPI.JSON_REQUEST+"/LoginSuccesful.json");
        reqresAPI.postLoginSuccessful(json);}

    @When("Send post login user request")
    public void sendPostLoginUserRequest() {
        SerenityRest.when().post(ReqresAPI.POST_LOGIN);}


    @And("Response body should be contain {string} as token")
    public void responseBodyShouldBeContainAsToken(String token) {
        SerenityRest.then()
                .body(ReqresResponses.TOKEN, equalTo(token));}


    //login Unsuccessful
    @Given("Post login user with invalid json")
    public void postLoginUnsuccessfulWithValidJson() {
        File json= new File (ReqresAPI.JSON_REQUEST+"/LoginUnsuccesful.json");
        reqresAPI.postLoginUnsuccessful(json);}

    //@Then("Should return status code {int}")
    //public void shouldReturnStatusCode(int statusCode) {SerenityRest.then().statusCode(statusCode);}

    @And("Response body should be contain error {string}")
    public void responseBodyShouldBeContainError(String error) {
        SerenityRest.then()
                .body(ReqresResponses.ERROR, equalTo(error));}



    }

