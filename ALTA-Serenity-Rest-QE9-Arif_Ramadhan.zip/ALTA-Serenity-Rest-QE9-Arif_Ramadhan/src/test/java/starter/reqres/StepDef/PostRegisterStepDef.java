package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.module.jsv.JsonSchemaValidator;
import jnr.constants.Constant;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;
import starter.reqres.ReqresResponses;

import java.io.File;

import static org.hamcrest.core.IsEqual.equalTo;

public class PostRegisterStepDef {
    @Steps
    ReqresAPI reqresAPI;

    @Given("Post register user with valid json")
    public void postRegisterUserWithValidJson() {
        File json = new File(ReqresAPI.JSON_REQUEST + "/RegisterSucces.json");
        reqresAPI.postRegister(json);
    }


    @When("Send post register user")
    public void sendPostRegisterUser() {
        SerenityRest.when().post(ReqresAPI.POST_REGISTER);
    }


    @Then("Should return status code {int}")
    public void statusCodeShouldBe(int code) {
        SerenityRest.then().statusCode(code);}


    @And("Response body should contain id {int} and token {string}")
    public void responseBodyShouldContainIdAndToken(int id, String token) {
        SerenityRest.then()
                .body(ReqresResponses.ID,equalTo(id))
                .body(ReqresResponses.TOKEN,equalTo(token));

    }

   @And("Validate post register json schema")    
   public void validatePostRegisterJsonSchema() {
        File json = new File(ReqresAPI.JSON_SCHEMA+"/PostLoginSuccesfulSchema.json");
        reqresAPI.postRegister(json);


   }

    @Given("Post register user with invalid json")
    public void postRegisterUserWithInvalidJson() {
        File json = new File(ReqresAPI.JSON_REQUEST + "/RegisterUserUnsucces.json");
        reqresAPI.postRegisterUnsuccesful(json);

    }

    @And("Response body should contain error {string}")
    public void responseBodyShouldContainError(String error) {
        SerenityRest.then()
                .body(ReqresResponses.ERROR,equalTo(error));
    }
}
