package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;

import java.io.File;

public class PutStepDef {
    @Steps
    ReqresAPI reqresAPI;

    @Given("Put update user with invalid json with id {int}")
    public void putUpdateUserWithInvalidJsonWithId(int id) {
        File json = new File( ReqresAPI.JSON_REQUEST+"/UpdateUserInvalid.json");
        reqresAPI.putUpdateUserInvalid(id,json);}

    @And("Validate json schema update user")
    public void validateJsonSchemaUpdateUser() {
        File json = new File(ReqresAPI.JSON_SCHEMA+"/PutUpdateUserSchema.json");
        reqresAPI.putUpdateUserValidate(json);
    }
}
