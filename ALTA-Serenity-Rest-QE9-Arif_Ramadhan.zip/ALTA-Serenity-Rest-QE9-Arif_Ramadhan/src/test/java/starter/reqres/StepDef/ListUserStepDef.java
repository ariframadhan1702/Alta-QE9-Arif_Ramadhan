package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.module.jsv.JsonSchemaValidator;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import org.hamcrest.Matchers;
import starter.reqres.ReqresAPI;
import starter.reqres.ReqresResponses;

import java.io.File;

import static org.hamcrest.core.IsEqual.equalTo;

public class ListUserStepDef {

    @Steps
    ReqresAPI reqresAPI;

    @Given("Get list users with invalid page {string}")
    public void setGetListUser(String page){ reqresAPI.setGetListUser(page);}

    @When("Send request get list user")
    public void sendRequestGetListUser(){
        SerenityRest.when().get(ReqresAPI.GET_LIST_USER); }

//    @And("Response body page should be {int}")
//    public void responseBodyPageShouldBe(int page) {
//        SerenityRest.then()
//                .body(ReqresResponses.PAGE, equalTo(page));
//    }

    @And("Validate json schema list user")
    public void validateJsonSchemaListUser() {
        File json = new File(ReqresAPI.JSON_SCHEMA +"/ListUserSchema.json");
        SerenityRest.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(json));}


//    @And("Response body should be <page>")
 //   public void responseBodyShouldBePage() {
//    }
}
