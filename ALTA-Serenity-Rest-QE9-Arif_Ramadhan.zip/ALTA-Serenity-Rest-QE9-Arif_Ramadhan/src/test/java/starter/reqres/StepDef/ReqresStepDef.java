package starter.reqres.StepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Steps;
import starter.reqres.ReqresAPI;

import java.io.File;

import static org.hamcrest.core.IsEqual.equalTo;

public class ReqresStepDef {
    @Steps
    ReqresAPI reqresAPI;

//scenario 1
    @Given("Get list users with page {int}")
    public void getListUserWithPage(int page){ reqresAPI.getListUsers(page);}


    @And("Response body page should be {int}")
    public void responseBodyPageShouldBe(int page) {
                SerenityRest.then().body("page",equalTo(page));}

   // @And("Get list user json schema validator")
   // public void getListUserJsonSchemaValidator() {
   //     File json = new File(ReqresAPI.JSON_REQUEST+"/RequestUser.json");
    //    SerenityRest.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(json));
   // }

    //scenario2
    @Given("Post create new user with valid json")
    public void postCreateUserWithValidJson() {
        File json= new File (ReqresAPI.JSON_REQUEST+"/RequestUser.json");
        reqresAPI.postCreateUser(json);
    }

    @When ("Send request post create user")
    public void sendRequestPostCreateUser(){
        SerenityRest.when().post(ReqresAPI.POST_CREATE_USER);
    }
    @And ("Response body name should be {string} and job {string}")
    public void responseBodyNameShouldBeAndJob(String name, String job){
        SerenityRest.then()
                .body("name",equalTo(name))
                .body("job",equalTo(job));
    }

    //scenario 3

    @Given ("Put update user with valid json with id {int}")
    public void putUpdateUserWithValidJsonWithId(int id) {
        File json = new File( ReqresAPI.JSON_REQUEST+"/RequestUser.json");
       reqresAPI.putUpdateUser(id,json);
    }

    @When("Send request put update user")
    public void sendRequestPutUpdateUser() {
        SerenityRest.when().put(ReqresAPI.PUT_UPDATE_USER);

    }

    //scenario 4
    @Given("Delete user with valid id {int}")
    public void deleteUserWithValidId(int id){
        reqresAPI.deleteUser(id);
    }



}
