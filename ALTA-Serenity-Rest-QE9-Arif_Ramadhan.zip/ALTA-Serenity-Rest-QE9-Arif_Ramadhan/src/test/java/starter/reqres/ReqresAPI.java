package starter.reqres;

import io.restassured.http.ContentType;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import java.io.File;

public class ReqresAPI {
    public static String BASE_URL = "https://reqres.in";

    public static final String DIR = System.getProperty("user.dir");

    public static String JSON_REQUEST = DIR+"/src/test/resources/JSON/Request";

    public static final String JSON_SCHEMA = DIR+ "/src/test/resources/JSON/JsonSchema";

    public static String GET_LIST_USER = BASE_URL +"/api/users?page={page}";

    public static String POST_CREATE_USER = BASE_URL +"/api/users";

    public static String POST_REGISTER = BASE_URL +"/api/register";
    public static String PUT_UPDATE_USER = BASE_URL +"/api/users/{id}";

    public static String DELETE_USER = BASE_URL+"/api/users/{id}";


    public static String POST_LOGIN = BASE_URL +"/api/login";

    public static String GET_SINGLE_USER = BASE_URL +"/api/users/{id}";

    public static String GET_DELAYED_RESPONSE = BASE_URL +"/api/users?delayed={page}";

    public static String GET_LIST_RESOURCE = BASE_URL + "/api/unknown?page={page}";





      @Step("Get list user")
    public void getListUsers(int page){
        SerenityRest.given().pathParam ("page",page);


    }
    @Step("Put update user")
        public void putUpdateUser(int id, File json){
        SerenityRest.given()
                .pathParam("id",id)
                .contentType(ContentType.JSON)
                .body(json);
        }

    @Step ("Delete user")
    public void deleteUser(int id){
          SerenityRest.given().pathParam("id",id);
    }

    @Step ("Post create user ")
    public void postCreateUser(File json){
        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(json);}

    @Step ("Post create user Invalid ")
    public void postCreateUserInvalid(File json){
        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(json);}

    @Step("Post Login Successful")
    public void postLoginSuccessful(File json){
        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(json);}

    @Step("Post Login Unsuccessful")
    public void postLoginUnsuccessful(File json){
        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(json);}

    @Step("Get single user")
    public void getSingleUsers(String id){
        SerenityRest.given().pathParam ("id",id);}

    @Step("Get list user")
    public void setGetListUser(String page){
        SerenityRest.given().pathParam ("page",page);}

    @Step("Post Register")
    public void postRegister(File json){
        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(json);}

    @Step("Post Register Unsuccesful")
    public void postRegisterUnsuccesful(File json){
        SerenityRest.given()
                .contentType(ContentType.JSON)
                .body(json);}

    @Step("Get Delayed Response")
    public void getDelayedResponse(int page){
        SerenityRest.given().pathParam ("page",page);}

    @Step("Put update user Invalid")
    public void putUpdateUserInvalid(int id, File json) {
        SerenityRest.given()
                .pathParam("id", id)
                .contentType(ContentType.JSON)
                .body(json);
    }

    @Step("Put update user validate")
    public void putUpdateUserValidate(File json) {
        SerenityRest.given()
               .contentType(ContentType.JSON)
               .body(json);
    }

    @Step("Get list resource")
    public void GetListResource(int page){
        SerenityRest.given()
                .pathParam("page", page);
    }


}


