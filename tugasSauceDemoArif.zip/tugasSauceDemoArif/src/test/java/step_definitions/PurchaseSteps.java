package step_definitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.example.pageObject.LandingPage;
import org.example.pageObject.UserInformationPage;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

public class PurchaseSteps {

    private WebDriver webDriver;

    public PurchaseSteps() {
        super();
        this.webDriver = Hooks.webDriver;
    }

    //Methode sort product list by name  Z to A
    @And("User sort product list by  \"(.*)\"")
    public void selectProductContainer(String sort) throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.selectProductContainer(sort);
        Thread.sleep(2000);
    }
    //Methode pick item Sauce Labs Onice
    @And("User pick item Sauce Labs Onice")
    public void clickItemBasket1() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.clickBasket1();
        Thread.sleep(2000);
    }
    //Methode pick item Test.allTheThingsT-Shirt
    @And("User pick item Test.allTheThingsT-Shirt")
    public void clickItemBasket2() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.clickBasket2();
        Thread.sleep(2000);

    }
    //Method click shopping cart
    @And("User click shopping cart")
    public void clickShoppingCart() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.clickShoppingCart();
        Thread.sleep(2000);
    }

    //Method For Direct to Landing Page use Products tags
    @Then("User directs in Landing Page and will see \"(.*)\" Tags")
    public void verifyLandingPage(String productTags) throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.verifylandingPageProductsTags();
        Assert.assertEquals(productTags, landingPage.verifylandingPageProductsTags());
        Thread.sleep(2000);
    }

    //Method Remove Button Item for item Test.allTheThingsT-ShirtRed
    @And("User Click Remove Button for 1 Item Test.allTheThingsT-ShirtRed")
    public void clickRemoveItem2() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.clickRemoveItem2();
        Thread.sleep(3000);
    }
    //Method Click Button CheckOut
    @And("User Click Button CheckOut")
    public void clickBtnCheckOut() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.clickBtnCheckOut();
        Thread.sleep(3000);
    }
    //Method Input Information Data of Buyer
    @When("User input \"(.*)\" as firstName and input \"(.*)\" as lastName and input \"(.*)\" as postal code")
    public void inputUserInformation(String firstrName, String lastName, String postalCode) throws InterruptedException {
        UserInformationPage userInformationPage = new UserInformationPage(webDriver);
        userInformationPage.setFirstName(firstrName);
        userInformationPage.setLastName(lastName);
        userInformationPage.setPostalCode(postalCode);
        userInformationPage.clickContinue();
        Thread.sleep(2000);
    }
    //Method Verify expected Item Total Before Tax
    @Then("Verify \"(.*)\" as expected item total")
    public void verifyItemTotal(String expectedItemTotal ) throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.verifyItemTotal();
        Assert.assertEquals(expectedItemTotal, landingPage.verifyItemTotal());
        Thread.sleep(3000);
    }
    //Method  Verify expected Amount of Tax
    @Then("Verify \"(.*)\" as expected tax")
    public void verifyTaxItem(String expectedTaxItem ) throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.verifyTaxItem();
        Assert.assertEquals(expectedTaxItem, landingPage.verifyTaxItem());
        Thread.sleep(3000);
    }

    //Method Verify expected Total Payment After Tax
    @Then("Verify \"(.*)\" as expected total payment")
    public void verifyTotal(String expectedOfPayment) throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.verifyTotal();
        Assert.assertEquals(expectedOfPayment, landingPage.verifyTotal());
        Thread.sleep(3000);
    }

    //Method click button finish
    @And("User Click Button Finish")
    public void clickButtonFinish() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.clickButtonFinish();
        Thread.sleep(3000);
    }

    //Method Verify page CheckOut Complete
    @Then("user will direct to page CheckOut Complete")
    public void verifyLandingPageChecKOutComplete() throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        Assert.assertTrue(landingPage.verifyLandingPageChecKOutComplete());
        Thread.sleep(3000);
    }

    //Method Verify Pop up message"THANK YOU FOR YOUR ORDER"
    @Then("Pop up message\"(.*)\"")
    public void verifyThanksPopUpMessage(String expectedPopUpMessage) throws InterruptedException {
        LandingPage landingPage = new LandingPage(webDriver);
        landingPage.verifyThanksPopUpMessage();
        Assert.assertEquals(expectedPopUpMessage, landingPage.verifyThanksPopUpMessage());
        Thread.sleep(3000);
    }


}

