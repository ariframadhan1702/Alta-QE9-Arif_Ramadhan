package org.example.pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LandingPage {

    public static WebDriver driver;

    public LandingPage(WebDriver driver){
        PageFactory.initElements(driver, this);
        this.driver = driver ;
    }

    @FindBy(xpath  = "//select[@class='product_sort_container']")
    private WebElement selectContainer;

    @FindBy(xpath = "//button[@id='add-to-cart-sauce-labs-onesie']")
    private WebElement basketItem1;

    @FindBy(xpath = "//button[@id='add-to-cart-test.allthethings()-t-shirt-(red)']")
    private WebElement basketItem2;

    @FindBy(xpath = "//span[@class='shopping_cart_badge']")
    private WebElement shoppingCart;

    @FindBy(xpath = "//span[@class='title']")
    private WebElement productsTags;


    @FindBy(xpath = "//button[@id='remove-test.allthethings()-t-shirt-(red)']")
    private WebElement removeItem2;

    @FindBy(xpath = "//button[@id='checkout']")
    private WebElement BtnCheckOut;

    @FindBy(xpath = "//div[@class='summary_subtotal_label']")
    private WebElement itemTotal;

    @FindBy(xpath = "//div[@class='summary_tax_label']")
    private WebElement taxItem;

    @FindBy(xpath = "//div[@class='summary_total_label']")
    private WebElement total;

    @FindBy(xpath = "//button[@id='finish']")
    private WebElement finishButton;

    @FindBy(xpath = "//h2[@class='complete-header']")
    private WebElement landingPageChecKOutComplete;

    @FindBy(xpath = "//h2[@class='complete-header']")
    private WebElement thanksPopUpMessage;


    public void selectProductContainer(String sortProductList){
        Select b = new Select (selectContainer);
        b.selectByVisibleText(sortProductList);
    }
    public void clickBasket1(){
        basketItem1.click();
    }

    public void clickBasket2(){
        basketItem2.click();
    }

    public void clickShoppingCart(){
        shoppingCart.click();
    }

    public String verifylandingPageProductsTags() {
        return productsTags.getText();

    }

    public void clickRemoveItem2(){
        removeItem2.click();
    }

    public void clickBtnCheckOut(){
        BtnCheckOut.click();
    }
    public String verifyItemTotal() {
        return itemTotal.getText();

    }
    public String verifyTaxItem() {
        return taxItem.getText();
    }

    public String verifyTotal() {
        return total.getText();
    }
    public void clickButtonFinish() {
        finishButton.click();
    }

    public boolean verifyLandingPageChecKOutComplete() {
        landingPageChecKOutComplete.isDisplayed();
        return true;

    }
    public String verifyThanksPopUpMessage() {
        return thanksPopUpMessage.getText();

    }

}
